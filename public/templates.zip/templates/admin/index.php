<div class="row">
    <!-- Barrita de buscador -->
    <div class="col-md-12">
        <!-- Search form -->
        <div class="col-md-8">
            <div class="card-head" >
                <!--va el titulo e la card-->
            </div><!--end .card-head -->
            <div class="card-body height-8">
                <div id="flot-visitors-legend" class="flot-legend-horizontal stick-top-right no-y-padding"></div>
                <div class="row">
                    <div class="col-md-3 col-md-offset-7 text-center">
                        <img ng-src="images/orochimaru_png.png" alt="" style="width: 208px;">
                    </div>
                </div>                    
                <div class="row">
                    <div class="col-md-3 col-md-offset-7 text-center">
                        <small>.::Efrain Colmenares::.</small>
                    </div>
                </div>
                <div id="flot-visitors" class="flot height-7" data-title="Activity entry" data-color="#7dd8d2,#0aa89e"></div>
            </div><!--end .card-body -->
        </div><!--end .col -->
    </div>
</div>


